#include "contador.h"

void contador::reset()
{
	cuenta_=0;
	min_=65000;
	max_=0;
	acumulado_=0;
	pruebas_=0;
}

void contador::stop()
{
	if(cuenta_>max_)
		max_=cuenta_;
	if(cuenta_<min_)
		min_=cuenta_;
	pruebas_++;
	acumulado_+=cuenta_;
}

const contador& contador:: operator++()
{
	cuenta_++;
	return *this;
}

ostream& operator<<(ostream& os, const contador& cont)
{
	os <<"\t"<<cont.min_<<"\t\t"<<cont.acumulado_/cont.pruebas_<<"\t\t"<<cont.max_<<endl;
	return os;
}