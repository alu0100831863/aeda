#pragma once

#include<cstdlib>
#include<time.h>

#include "sort_type.h"
#include "insertion.h"
#include "bubblesort.h"
#include "mergesort.h"
#include "quicksort.h"
#include "shellsort.h"
#include "dni.h"

template <class T>
class experimento {
	private:
		sort_type<T>* algorithm_;
		unsigned npruebas_;
		char sort_type_;
		T** bench_;
		int sz_;
		int comp_;
	public:
		experimento();
		~experimento();

		void iniciar_experimento();

	private:
		void inicializar();
		void modo_prueba();
};

template <class T>
experimento<T>::experimento()
{
	algorithm_=NULL;
	npruebas_=0;
	bench_=NULL;
	sz_=0;
	comp_=0;
	this->inicializar();
}

template <class T>
experimento<T>::~experimento(){}

template <class T>
void experimento<T>::inicializar()
{
	cout<<"Dimension de la secuencia a ordenar: ";
	cin>>sz_;

		if (sz_ > 25)
		{
			cout<<"La dimension maxima en modo demostracion es 25. La dimension tendra este valor."<<endl;
			sz_=25;
		}
		cout<<"Algoritmo a ejecutar: "<<endl;
		cout<<"[i]nsercion\t[b]urbuja\t[m]ergesort\t[h]shellsort\t[q]uicksort"<<endl;
		cin>>sort_type_;
		
		npruebas_=1;

		/**/

	bench_=new T*[npruebas_];
	for(int i=0;i<npruebas_;i++)
	{
		bench_[i]=new T[sz_];
		for(int j=0;j<sz_;j++)
		{
			bench_[i][j]=(rand()%50000000)+30000000 + (const char*)("a" + rand() % 26);
		}
	}
	
	cout<<"Banco creado!"<<endl;
	cout<<"Datos preparados!"<<endl;
}

template <class T>
void experimento<T>::modo_prueba()
{
	switch(sort_type_)
	{
		case 'i':
			algorithm_=new insertion<T>;
		break;

		case 'm':
			algorithm_=new mergesort<T>;
		break;

		case 'b':
			algorithm_=new bubblesort<T>;
		break;

		case 'h':
			algorithm_=new shellsort<T>;
		break;

		case 'q':
			algorithm_=new quicksort<T>;
		break;
	}
	
	for(int i=0;i<sz_;i++)
		cout<<bench_[0][i]<<" ";
	cout<<endl;

	algorithm_->sort(bench_[0], sz_, comp_);

	for(int i=0;i<sz_;i++)
		cout<<bench_[0][i]<<" ";
	cout<<endl;

}

template <class T>
void experimento<T>::iniciar_experimento()
{
	modo_prueba();
}
