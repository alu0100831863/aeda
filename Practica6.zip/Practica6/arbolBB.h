#pragma once

#include "nodoBB.h"
#include "dni.h"
#include "contador.h"
#include <queue>

using namespace std;

template <class T>
class arbolBB{
	private:
		nodoBB<T> *root_;
		contador cont_;
		
	public:
		arbolBB(nodoBB<T> *root);
		inline ~arbolBB() {podar(root_);};
		
		void podar(nodoBB<T>* nodo);
		inline nodoBB<T>* get_root() {return root_;};
		
		inline bool es_vacio(){return root_==NULL;};
		inline bool es_hoja(nodoBB<T> *nodo) {return (!nodo->get_izdo() && !nodo->get_dcho());};
		
		void pre_orden(nodoBB<T> *nodo);
		void post_orden(nodoBB<T> *nodo);
		void in_orden(nodoBB<T> *nodo);

		inline void imprimir_dato(nodoBB<T>* nodo) {cout<<nodo->get_clave();};
		void imprimir(nodoBB<T> *nodo, int nivel);
		inline void imprimir_contador() {cout<<cont_;};
		
		void recorreN(nodoBB<T> *root);
		
		void insertar(T clave_dada);
		void insertarRama(nodoBB<T>* &nodo, T clave_dada);
		
		nodoBB<T>* buscar(T clave_dada);
		nodoBB<T>* buscarRama(nodoBB<T>* nodo,T clave_dada);
		
		void eliminar(T clave_dada) {eliminarRama(root_,clave_dada);};
		inline void eliminarRama(nodoBB<T>* &nodo, T clave_dada);
		void sustituye(nodoBB<T>* &eliminado,nodoBB<T>* &sust);
		
	inline int get_min(){return cont_.get_min();};
	inline int get_cuenta(){return cont_.get_cuenta();};
	inline int get_max(){ return cont_.get_max();};
	inline int get_acum(){return cont_.get_acum();};
	inline int get_pruebas(){return cont_.get_pruebas();};
};

template<class T>
struct NIV
{
		nodoBB<T>* node=NULL;
		int niv;
};

int aux=-1;


template <class T>
arbolBB<T>::arbolBB(nodoBB<T> *root=NULL):
	root_(root){}

template<class T>
void arbolBB<T>:: podar(nodoBB<T>* nodo)
{
	if(nodo==NULL) return;
	podar(nodo->get_izdo());
	podar(nodo->get_dcho());
	if(nodo!=NULL)
	{
		delete nodo;
		nodo=NULL;
	}
}

template <class T>
void arbolBB<T>::pre_orden(nodoBB<T> *nodo)
{
	if (nodo == NULL) return;
	imprimir_dato(nodo);
	cout<<"\t";
	pre_orden(nodo->get_izdo());
	pre_orden(nodo->get_dcho());
}

template <class T>
void arbolBB<T>::in_orden(nodoBB<T> *nodo)
{
	if (nodo == NULL) return;
	in_orden(nodo->get_izdo());
	imprimir_dato(nodo);
	cout<<"\t";
	in_orden(nodo->get_dcho());
}

template <class T>
void arbolBB<T>:: post_orden(nodoBB<T> *nodo)
{
	if (nodo == NULL) return;
	post_orden(nodo->get_izdo());
	post_orden(nodo->get_dcho());
	imprimir_dato(nodo);
	cout<<"\t";
}

template<class T>
void arbolBB<T>:: imprimir(nodoBB<T> *nodo, int nivel)
{
	
	if(root_==NULL)
	{
		cout<<"Arbol vacio"<<endl;
		cout<<"Nivel 0: [.]"<<endl;
	}
	else
	{
		if(nivel>aux)
		{ 
			cout<<endl;
			cout<<"Nivel"<<nivel<<":";
			if(nodo==NULL)
				cout<<"[.]";
			else
			{
				cout<<"[";
				cout<<nodo->get_clave();
				cout<<"]";
			}			
		}
		else
		{
			if(nodo==NULL)
				cout<<"[.]";
			else
			{
				cout<<"[";
				cout<<nodo->get_clave();
				cout<<"]";
			}
			
		}
	}	
	aux=nivel;
}

template <class T>
void arbolBB<T>::recorreN(nodoBB<T> *root)
{

	NIV<T> rootS;
	NIV<T> nodoS;
	NIV<T> naux;

	rootS.node=root;
	rootS.niv=0;	
	queue<NIV <T> > Q;
	int nivel_actual=0;
	Q.push(rootS);

	while(!Q.empty())
	{
		nodoS=Q.front();
		Q.pop();
		if(nodoS.niv > nivel_actual)
			nivel_actual=nodoS.niv;
		if(nodoS.node!= NULL)
		{
			imprimir(nodoS.node,nivel_actual);
			naux.niv=nodoS.niv;
			naux.node=nodoS.node->get_izdo();
			naux.niv=naux.niv+1;			
			Q.push(naux);
			naux.node=nodoS.node->get_dcho();
			Q.push(naux);
		}
		else 
			imprimir(nodoS.node,nivel_actual);
	}
	aux=-1;
	cout<<endl;
}

template <class T>
void arbolBB<T>:: insertar(T clave_dada)
{
	cont_.reset();
	cont_.start();
	insertarRama(root_,clave_dada);
	cont_.stop();
}

template <class T>
void arbolBB<T>:: insertarRama(nodoBB<T>* &nodo, T clave_dada)
{
	++cont_;
	if(nodo == NULL)
		nodo = new nodoBB<T>(clave_dada,NULL,NULL);
	else if (clave_dada < nodo->get_clave())
			insertarRama(nodo->get_izdo(),clave_dada);
		else
			insertarRama(nodo->get_dcho(),clave_dada);		
}

template<class T>
nodoBB<T>* arbolBB<T>::buscar(T clave_dada)
{
	cont_.start();
	nodoBB<T> *nodo=buscarRama(root_,clave_dada);
	cont_.stop();
	return nodo;
}

template<class T>
nodoBB<T>* arbolBB<T>::buscarRama(nodoBB<T>* nodo, T clave_dada)
{
	++cont_;
	if(nodo==NULL)
		return NULL;
	if(clave_dada==nodo->get_clave())
		return nodo;
	if(clave_dada <nodo->get_clave())
		return buscarRama(nodo->get_izdo(),clave_dada);
	return buscarRama(nodo->get_dcho(),clave_dada);
}

template <class T>
void arbolBB<T>::eliminarRama(nodoBB<T>* &nodo,T clave_dada)
{
	if(nodo == NULL)
		return;
	if(clave_dada <nodo->get_clave())
		eliminarRama(nodo->get_izdo(),clave_dada);
		else if(clave_dada > nodo->get_clave())
			eliminarRama(nodo->get_dcho(),clave_dada);
			else
			{
				nodoBB<T>* eliminado=nodo;
				if(nodo->get_dcho() == NULL)
					nodo=nodo->get_izdo();
				else if(nodo->get_izdo()==NULL)
					nodo=nodo->get_dcho();
				else
					sustituye(eliminado,nodo->get_izdo());
				
				if(eliminado!=NULL)
				{
					delete(eliminado);
					eliminado=NULL;
				}
			}
}

template <class T>
void arbolBB<T>::sustituye(nodoBB<T>* &eliminado,nodoBB<T>* &sust)
{
	if(sust->get_dcho() != NULL)
		sustituye(eliminado,sust->get_dcho());
	else
	{
		eliminado->set_clave(sust->get_clave());
		eliminado=sust;
		sust=sust->get_izdo();
	}
}