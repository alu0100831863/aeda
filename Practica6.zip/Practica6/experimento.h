#pragma once

#include <cstdlib>
#include "arbolBB.h"
#include "dni.h"
#include <iomanip>

template <class T>
class experimento {
	private:
		arbolBB<T>* Tree_;
		int N_;
		int P_;
		T* bench_;
	
	public:
		inline experimento() {inicializar();};
		~experimento();
		
		void get_info();
		void inicializar();
		
		void pinsercion();
		void pbusqueda();
		
		void estadistica();
		
};

template <class T>
experimento<T>::~experimento()
{
	if (bench_!=NULL)
		delete bench_;
	bench_=NULL;
}

template <class T>
void experimento<T>::get_info()
{
	cout<<"Dimension del arbol: ";
	cin>>N_;
	cout<<"Numero de pruebas: ";
	cin>>P_;
	if(P_>N_)
	{
		cout<<"El numero de pruebas debe ser como maximo la dimension del arbol. "<<endl;
		cout<<"Numero de pruebas se cambiara a : "<<N_;
		P_=N_;
	}
	bench_=new T [2*N_];
}

template <class T>
void experimento<T>::inicializar()
{
	Tree_=new arbolBB<T>;
	for(int i=0;i<2*N_;i++)
		bench_[i] = (rand()%50000000)+30000000;
	for(int i=0;i<N_;i++)
		Tree_->insertar(bench_[i]);
}

template <class T>
void experimento<T>::pinsercion()
{
	for(int i=N_;i<(N_+P_);i++)
		Tree_->insertar(bench_[i]);
}

template <class T>
void experimento<T>::pbusqueda()
{
	for(int i=0;i<P_;i++)
		Tree_->insertar(bench_[i]);
}

template <class T>
void experimento<T>::estadistica()
{

	int min=65000;
	int max=0;
	int med;
	int acmin=0;
	int acmax=0;
	get_info();
	for(int i=0;i<P_;i++)
	{
		inicializar();
			pbusqueda();
			if (min>Tree_->get_min())
					min=Tree_->get_min();
			if(max<Tree_->get_max())
					max=Tree_->get_max();
				acmin+=min;
				acmax+=max;
	}
	med=(acmin+acmax)/(P_*2);
	cout<<"\n---------------------------------------------------------------------------"<<endl;
	cout<<setw(15)<<"N"<<setw(10)<<"P"<<setw(10)<<"Minimo"<<setw(10)<<"Medio"<<setw(10)<<"Maximo"<<endl;
	cout<<"Busqueda"<<setw(7)<<N_<<setw(10)<<P_<<setw(10)<<min<<setw(10)<<med<<setw(10)<<max<<endl;
	
	min=65000;
	max=0;
	acmin=0;
	acmax=0;
	for(int i=N_;i<N_+P_;i++)
	{
		inicializar();
			pinsercion();
			if (min>Tree_->get_min())
					min=Tree_->get_min();
			if(max<Tree_->get_max())
					max=Tree_->get_max();
				acmin+=min;
				acmax+=max;
	}
	med=(acmin+acmax)/(P_*2);
		cout<<"Insercion"<<setw(6)<<N_<<setw(10)<<P_<<setw(10)<<min<<setw(10)<<med<<setw(10)<<max<<endl;
		cout<<"---------------------------------------------------------------------------"<<endl;
}