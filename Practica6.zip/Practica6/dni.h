#pragma once

#include <iostream>
#include <iomanip>

using namespace std;

class dni {
	private:
		int value_;
		
	public:
		dni();
		dni(unsigned);
		dni(dni&);
		~dni();
		
		int get_value();
		
		unsigned operator %(int);
		bool operator==(dni&) const;
		bool operator==(int) const;
		bool operator <(dni&) const;
		bool operator >(dni&) const;
		dni& operator= (dni&);
		dni& operator = (int);
		
		ostream& imprimir(ostream&) const;
		friend ostream& operator <<(ostream&, dni&);
};







