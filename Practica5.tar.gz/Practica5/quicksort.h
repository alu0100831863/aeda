#pragma once

#include "sort_type.h"

template <class T>
class quicksort: public sort_type<T> {
	public:
		quicksort(){};
		virtual ~quicksort(){};
		void sort(T*, int, int&);
		void qsort(T* v,int ini, int fin, int&);
};


template <class T>
void quicksort<T>::sort(T* v, int sz, int& cont){
	qsort(v,0,sz-1,cont);
}

template <class T>
void quicksort<T>::qsort(T* v,int ini, int fin, int& cont){
	int i=ini;
  int f=fin;
  T p=v[(i+f)/2];
  while(i<=f){
		cout<<"Pivote: "<<p<<endl;
    while (v[i] < p){
      i++;
			cout<<"Comparando: "<<v[i]<<endl;
		}
    cont++;
    while (v[f] > p){
			cout<<"Comparando: "<<v[f]<<endl;
      f--;
		}
    cont++;
    if(i<=f){
      T x=v[i];
      v[i]=v[f];
      v[f]=x;
      i++;
      f--;
    }
		for(int i=ini;i<=fin;i++)
			cout<<v[i]<<" ";
		cout<<endl;
  }
	if(ini<f)
  	qsort(v,ini,f,cont);
	if(i<fin)
    qsort(v,i,fin,cont);
}
