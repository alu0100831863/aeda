#include "experimento.h"

int main()
{
	experimento<dni> E;
	E.iniciar_experimento();	
}
