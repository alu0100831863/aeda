#include "dni.h"

dni::dni()
{
  value_=0;
  letra_=0;
}

dni::dni(unsigned value, char letra)
{
  value_=value;
  letra_=letra;
}

dni::dni(dni& n)
{
  value_=n.value_;
  letra_=n.letra_;
}

dni::~dni()
{
  value_=0;
  letra_=0;
}

int dni::get_value()
{
	return value_;
}

char dni::get_letra()
{
	return letra_;
}

unsigned dni::operator %(int n)
{
  return value_%n;
}

char dni::operator %(char n)
{
	return letra_%n;
}

bool dni::operator==(dni& n) const
{
  return value_==n.value_;
}

bool dni::operator==(int n) const
{
	return value_==n;
}

bool dni::operator==(char n) const
{
	return letra_==n;
}

bool dni::operator <(dni& n) const
{
	if(value_ < n.value_)
		return true;
	else
		return false;
}

bool dni::operator >(dni& n) const
{
	if(value_ > n.value_)
		return true;
	else
		return false;
}

dni& dni::operator = (dni& n)
{
	value_= n.value_;
	return *this;
}

dni& dni::operator = (int i)
{
	value_=i;
	return *this;
}

dni& dni::operator = (char i)
{
	letra_=i;
	return *this;
}

dni& dni::operator = (const char* i)
{
	const char* aux;
	aux=i;
	return *this;
}

ostream& dni::imprimir(ostream& os) const
{
  os << value_ << letra_;
  return os;
}

ostream& operator <<(ostream& os, dni& n)
{
	os << n.value_ << n.letra_;
	return os;
}