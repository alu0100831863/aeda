#pragma once

#include "sort_type.h"

template <class T>
class mergesort: public sort_type<T> {
	public:
		mergesort(){};
		virtual ~mergesort(){};
		void sort(T*,int,int&);
		void msort(T* v, int ini, int fin,int& cont);
		void mix(T* v, int ini, int cen, int fin, int& cont);
};


template <class T>
void mergesort<T>::sort(T* v,int sz,int& cont){
 msort(v,0,sz-1,cont);
}

template <class T>
void mergesort<T>::msort(T* v, int ini, int fin,int& cont){
  if(ini<fin){
		int cen=(ini+fin)/2;
		for(int i=0;i<=fin;i++){
		  cout<<v[i]<<" ";
		}
		cout<<endl;
		msort(v,ini,cen,cont);
		for(int i=cen+1;i<=fin;i++){
		  cout<<v[i]<<" ";
		}
		cout<<endl;
		cout<<endl;
		msort(v,cen+1,fin,cont);
		mix(v,ini,cen,fin,cont);
		for(int i=0;i<=fin;i++){
		  cout<<v[i]<<" ";
		}
		cout<<endl;
  }
}

template <class T>
void mergesort<T>::mix(T* v, int ini, int cen, int fin, int& cont){
  int i=ini;
  int j=cen+1;
  int k=ini;
  T* aux;
  aux=new T[fin];

  while((i<=cen)&&(j<=fin)){
			if(v[i]<v[j]){
      	aux[k]=v[i];
      	i++;
    	}
			else{
      	aux[k]=v[j];
      	j++;
    	}
    	k++;
    	cont++;
  }
  cout<<endl;
  while(i<=cen){
    aux[k]=v[i];
    i++;
    k++;
  }
  while(j<fin){
    aux[k]=v[j];
    j++;
    k++;
  }
  for(i=ini;i<k;i++){
    v[i]=aux[i];
  }
}
