#include "dni.h"

dni::dni()
{
  value_=0;
}

dni::dni(unsigned value)
{
  value_=value;
}

dni::dni(dni& n)
{
  value_=n.value_;
}

dni::~dni()
{
  value_=0;
}

int dni::get_value()
{
	return value_;
}

unsigned dni::operator %(int n)
{
  return value_%n;
}

bool dni::operator==(dni& n) const
{
  return value_==n.value_;
}

bool dni::operator==(int n) const
{
	return value_==n;
}

bool dni::operator <(dni& n) const
{
	if(value_ < n.value_)
		return true;
	else
		return false;
}

bool dni::operator >(dni& n) const
{
	if(value_ > n.value_)
		return true;
	else
		return false;
}

dni& dni::operator = (dni& n)
{
	value_= n.value_;
	return *this;
}

dni& dni::operator = (int i)
{
	value_=i;
	return *this;
}

ostream& dni::imprimir(ostream& os) const
{
  os << value_;
  return os;
}

ostream& operator <<(ostream& os, dni& n)
{
	os << n.value_;
	return os;
}