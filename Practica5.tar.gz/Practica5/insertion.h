#pragma once

#include "sort_type.h"

template <class T>
class insertion: public sort_type<T> {
	public:
		insertion(){};
		virtual ~insertion(){};
		void sort(T* ,int, int&);
};


template <class T>
void insertion<T>::sort(T* v, int sz, int& cont){
	for(int i=0;i<sz;i++){  //Impresión por pantalla del estado actual del vector
			cout<<v[i]<<" ";
	}
  for (int i=0;i <sz;i++){
			int j=i;
			T x=v[i];
			v[-1]=x;
			cout<<"\nComparando: "<<v[i]<<" ";
			cout<<"Con: "<<v[j]<<" ";
			while(x < v[j-1]){
					v[j]=v[j-1];
					cout<<"Con: "<<v[j]<<" ";
					j--;
					cont++;
			}
			v[j]=x;
			cout<<endl;
			cout<<endl;
			for(int i=0;i<sz;i++)
					cout<<v[i]<<" ";
			cout<<endl;
  }
}
