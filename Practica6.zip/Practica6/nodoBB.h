#pragma once

#include <iostream>
#include "dni.h"

using namespace std;

template <class T>
class nodoBB {
	private:
		T clave_;
		nodoBB *izdo_;
		nodoBB *dcho_;

	public:
		inline nodoBB(T clave, nodoBB<T> *izdo=NULL, nodoBB<T> *dcho=NULL): clave_(clave), izdo_(izdo), dcho_(dcho){}
		~nodoBB();
		
		inline nodoBB<T>*& get_izdo() {return izdo_;}
		inline nodoBB<T>*& get_dcho() {return dcho_;}
		
		inline void set_izq(nodoBB<T>* nodo) {izdo_=nodo;}
		inline void set_dcho(nodoBB<T>* nodo) {dcho_=nodo;}
		
		inline T get_clave() {return clave_;}
		void set_clave(T clave) {clave_=clave;}
	};

	template<class T>
	nodoBB<T>::~nodoBB()
	{/*
		if(&izdo_!=NULL)
		{
			delete izdo_;
			izdo_=NULL;
		}

		if(&dcho_!=NULL)
		{
			delete dcho_;
			dcho_=NULL;
		}*/
	}