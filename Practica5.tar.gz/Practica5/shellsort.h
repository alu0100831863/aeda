#pragma once

#include "sort_type.h"

#define delta 0.3

template <class T>
class shellsort: public sort_type<T> {
	public:
		shellsort(){};
		virtual ~shellsort(){};
		void sort(T*, int, int&);
		void deltasort(int d,T* v, int sz,int& cont);
};


template <class T>
void shellsort<T>::sort(T* v, int sz, int& cont){
	   	int del=sz;
     	for(int i=0;i<sz;i++){
      cout<<v[i]<<" ";
     	}
  		while(del>0){
    		del=del*delta;
    		deltasort(del,v,sz-1,cont);
  		}
    	cout<<endl;
    	for(int i=0;i<sz;i++){
      	cout<<v[i]<<" ";
    	}
  		cout<<endl;
}

template <class T>
void shellsort<T>::deltasort(int d,T* v, int sz,int& cont){
	  for(int i=d+1;i<=sz;i++){
			T x=v[i];
			int j=i;
			while((j>d)&&(x<v[j-d])){
		  	v[j]=v[j-d];
		  	j=j-d;
			}
			cont++;
			v[j]=x;
		}
}
