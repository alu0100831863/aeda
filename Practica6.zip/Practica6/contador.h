#pragma once
#include <iostream>

using namespace std;

class contador {
  private:
    int cuenta_;
    int min_;
    int max_;
    int acumulado_;
    int pruebas_;

  public:
    inline contador() {reset();};
	inline ~contador() {};
    void reset();
	inline void start(){cuenta_=0;};
    void stop();
    const contador& operator++();
	
	inline int get_min(){return min_;};
	inline int get_cuenta(){return cuenta_;};
	inline int get_max(){ return max_;};
	inline int get_acum(){return acumulado_;};
	inline int get_pruebas(){return pruebas_;};
	
    friend ostream& operator<<(ostream& sout, const contador& cont);
};