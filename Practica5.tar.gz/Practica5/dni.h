#pragma once

#include <iostream>
#include <iomanip>

using namespace std;

class dni {
	private:
		int value_;
		char letra_;
		
	public:
		dni();
		dni(unsigned,char);
		dni(dni&);
		~dni();
		
		int get_value();
		char get_letra();
		
		unsigned operator %(int);
		char operator %(char);
		bool operator==(dni&) const;
		bool operator==(int) const;
		bool operator==(char) const;
		bool operator <(dni&) const;
		bool operator >(dni&) const;
		dni& operator= (dni&);
		dni& operator = (int);
		dni& operator = (char);
		dni& operator = (const char*);
		
		ostream& imprimir(ostream&) const;
		friend ostream& operator <<(ostream&, dni&);
};







