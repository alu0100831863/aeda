#pragma once

#include "sort_type.h"

template <class T>
class bubblesort: public sort_type<T> {
	public:
		bubblesort(){};
		virtual ~bubblesort(){};
		void sort(T*, int, int&);
};


template <class T>
void bubblesort<T>::sort(T* v, int sz, int& cont){
  for(int i=0;i<sz;i++){  //Impresión por pantalla del estado actual del vector
      cout<<v[i]<<" ";
  }
  cout<<endl;
  T a;
  for (int i=1;i<=sz;i++){
        for (int j=0;j<sz-i ;j++){
            if(v[j]>v[j+1]){
                a=v[j];
                v[j]=v[j+1];
                v[j+1]=a;
            }
        }
  }
}