#include <cstring>
#include "nodoBB.h"
#include "arbolBB.h"
#include "dni.h"

using namespace std;


int main ()
{
	char opt;
	int k;
	arbolBB<int> Tree;
	
	do
	{
		cout<<" === MENU ==="<<endl;
		cout<<" 1 Insertar clave \n 2 eliminar clave \n 3 salir"<<endl;
		cin>> opt;
		
		switch(opt)
		{
			case '1':
				cout<<"Introducir clave: ";
				cin>> k;
				Tree.insertar(k);
				Tree.recorreN(Tree.get_root());
			break;
			
			case '2':
				cout<<"Introducir clave: ";
				cin>> k;
				Tree.eliminar(k);
				Tree.recorreN(Tree.get_root());
			break;
			
			default:
				opt = 's';
			break;
		}
		
	}while(opt!='s');
}