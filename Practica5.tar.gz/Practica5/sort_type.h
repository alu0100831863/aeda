#pragma once

#include <iostream>

using namespace std;

template <class T>
class sort_type {
	public:
		sort_type(){};
		virtual ~sort_type(){};
		virtual void sort(T*, int, int&)=0;
};