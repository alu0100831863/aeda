#include<cstdlib>
#include "arbolBB.h"
#include "experimento.h"
#include "contador.h"

int main (){

	experimento<int> E;
	
	E.estadistica();

}